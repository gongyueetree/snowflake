# Snowflake Studio · 雪花灯创作台

面向非程序员的雪花灯拼接、灯效仿真、Gemini 自然语言创作与 RP2040 UF2 下载工具。

## 已实现

- 1～12 片雪花灯；拖动、旋转、复制、删除；四种快速布局；撤销与重做；级联顺序调整。
- 真实 KiCad PCB 的 37 颗灯珠坐标和 114 段闭合板框，位号 D1～D37 可显示。
- 20 组预设，18 种可组合灯效：常亮、呼吸、光波、彩虹、流星、闪烁、旋转、径向波纹；最多六层。
- Gemini 通过 Google REST API 将自然语言和当前场景转换为严格校验的灯效描述。仅执行受支持的效果，不执行模型生成的任意代码。
- 时间轴、播放暂停、亮度、颜色、2～30 秒循环，空间效果随灯板位置和旋转变化。
- 项目 JSON 导入导出和浏览器本地保存。密钥只在页面内存中，不写入 localStorage、项目或源码；请求直接到 Google。
- 本地打包真正 UF2：已编译的 RP2040 PIO 播放器 + 当前场景的 RGB 像素帧 + CRC32。无需云端编译服务。

## 使用

打开网站 → 选择板数并布局 → 选择预设，或点击“连接 Gemini”填写个人 Google AI Studio API 密钥 → 描述效果并生成 → 预览、调整 → “下载固件” → 阅读接线页 → 生成 UF2。

按住 LA RP2040 的 SW4 / BOOT 后插入 USB，出现 RPI-RP2 磁盘后将 UF2 拖入。自动重启后循环播放。烧录会替换原来的调试器/下载器程序；需要恢复时重新烧录原固件。播放固件没有 USB 串口，重新下载需再次按住 BOOT 插入。

## 硬件核查

来自用户提供的 `SnowFlake.zip` 和 `LA_RP2040.zip`：

- WS2812B: pad 1 VDD, pad 2 DOUT, pad 3 GND, pad 4 DIN。
- 雪花 J1 输入：1=5V，2=DIN，3=GND。J2 输出：1=5V，2=DOUT，3=GND。
- J1.2 → D1.4；逐一核对 36 个 DOUT→DIN 网络后确认 D1→D37；D37.2→J2.2。
- D1 位于中心 (150,90) mm；网站坐标以其为原点；采用 PCB 顶面视图。组合摆放影响全局空间效果，左右列表顺序决定实际数据串联顺序。
- 控制器 U2=RP2040，U3=GD25Q64 8 MiB SPI Flash，Y1=12MHz。
- 输出 J2 对应：GP20=3，GP21=5，GP22=7，GP23=9，GP24=11，GP25=6，GP26=8，GP27=10，GP28=12。J2.1 为 GND，J2.2 为 3V3，J2.4 为 5V。
- 默认数据引脚 GP20 (J2.3)。没有把 GP0 当作灯板数据口；GP0 接板载 LED。

供电：单片按旧版 WS2812B 每灯满白 60mA 保守估算为 2.22A / 11.1W；不同版本实耗不同。多板使用独立 5V 电源并并联分配电源线，按线径、接插件额定电流与压降设计供电，不能让全部电流流经控制器 USB 或细长板间线路。外部 5V 接灯板，控制器和灯板共地，避免外部 5V 反灌电脑。RP2040 3.3V 逻辑不保证满足老版 WS2812B 5V 下的 VIH，建议 74AHCT125 等单向 5V 电平转换，数据串联约 330Ω，电源入口储能电容。第一轮单板低亮度试灯。

## 固件与预览一致性

浏览器预览和导出都调用 `renderFrame(scene, boards, t)`。导出把循环时间按 fps 量化为 RGB 帧；RP2040 从 Flash 顺序读出，转换 GRB，以 PIO 输出。屏幕辉光、色彩和实际灯珠光学表现仍会不同；没有标定屏幕伽马与 LED 色彩。

- UF2 family: `0xe48bff56` (RP2040), blocks: 512 bytes, payload: 256 bytes.
- Runtime: `0x10000000`，8104 bytes（当前构建）。
- Frame header: `0x10040000`，固定 256 bytes；帧从 `0x10040100` 开始。
- Header 8 个 little-endian uint32: magic=0x534e4f57, version=1, LED count, frame count, fps, GPIO, data byte length, CRC32。
- Runtime 启动先检查长度、LED 数、帧数、引脚范围、CRC；无效数据不会启动 GPIO 输出。
- 三片默认 8 秒 30fps 场景：111 LEDs × 240 frames × 3 bytes；UF2 共 177152 bytes。
- 最大 12 片/30秒/30fps：1,198,800 bytes 帧数据，低于 GD25Q64 的 8 MiB 容量。
- `boot2_generic_03h` 通用串行读取启动，避免假设 Flash 的特定 Quad-enable 写法。
- PIO: 8MHz 状态机，T1/T2/T3=3/3/4，总每位 10 周期 → 800kbit/s。T0H=375ns，T1H=750ns；发送 GRB MSB first。等 TX FIFO 空后再等待 400µs，覆盖最后一个字的 30µs 传输并留出 >280µs 复位低电平。
- 12 片总数据时间 13.32ms，低于 30fps 的 33.33ms 帧周期。

这是有限时长动画帧播放器，不是任意 C 程序生成器。适合重复展示灯效；支持原始音频在浏览器内分析并烘焙节奏；不支持硬件实时麦克风音乐响应、无限随机程序、文字/图像任意映射。描述超出能力时 Gemini 被要求说明并给出可支持的近似。

## 开发与重新构建

网页无构建依赖，`dist/` 直接提供静态资源。运行 `node tests.mjs` 做非浏览器检查。

固件构建依赖 CMake、Ninja、ARM GNU GCC 及 Pico SDK。本次使用 ARM GCC 14.2.1 和 Pico SDK commit `079c6f39023649b154152db30f1d781e884879bc`。

```sh
export PICO_SDK_PATH=/absolute/path/to/pico-sdk
export PICO_TOOLCHAIN_PATH=/absolute/path/to/arm-toolchain
cmake -S firmware -B build -G Ninja -DPICO_NO_PICOTOOL=1
cmake --build build
cp build/runtime.bin dist/runtime.bin
node tests.mjs
```

无需 TinyUSB（运行时不提供 USB 功能）。不要将 API key 放进静态文件。页面个人密钥方案用于本人原型试用；若未来面向公众运营，应由服务器保存平台密钥并增加用户身份、额度、限流、审计等，不应把平台共用密钥发到浏览器。

## 验证范围

通过：ARM 实际编译；启动向量与 boot2 CRC；真实坐标与引脚映射；20 组预设循环连续；目标板隔离；输入拒绝校验；UF2 块头/芯片标识/地址/长度/CRC；解包像素与预览逐帧一致；浏览器页面、预设、旋转、复制、撤销、生成下载操作。

未通过实物验证：时序示波器测量、外部供电、LED 批次电平阈值、板上 Flash 启动兼容性、真实灯效。没有用户 Gemini key，未执行收费模型调用；连接和生成请求需要用户在页面验证。

## 参考与许可

- Raspberry Pi WS2812 PIO 示例 (BSD-3-Clause): https://github.com/raspberrypi/pico-examples/blob/master/pio/ws2812/ws2812.pio
- Pico SDK: https://github.com/raspberrypi/pico-sdk
- Worldsemi WS2812B 数据手册: https://cdn-shop.adafruit.com/datasheets/WS2812B.pdf
- Gemini structured output: https://ai.google.dev/gemini-api/docs/generate-content/structured-output

Pico SDK / PIO 相关 BSD 许可文本见 `firmware/PICO_LICENSE.txt`。上传硬件工程版权归其原作者。


## v1.1 · 发光渲染、20 个示例与音乐

修复上一版的显示偏暗：LED 彩色点的发光面积太小，光晕只到 5.8mm，缺少亮芯与叠加溢光。现在采用 15mm 多层光晕、接近白色的高亮核心和加法混合。`displayLight` 中曝光映射只用于屏幕显示；`renderFrame` 和 UF2 数据保持实际 RGB 亮度逻辑。辉光模式可切回像素视图；曝光不改变硬件亮度、输出电流或固件。屏幕不是物理光度标定仪，不能复现实物绝对亮度。

示例共 20 个：极光森林、冬日初雪、圣诞来信、日落余晖、星际流星、层层绽放、深海潮汐、烛火晚餐、糖果圣诞、节日星光、六瓣轮舞、螺旋星云、雷达扫描、双向彗星、霓虹扫描、彩纸派对、飘雪之夜、烟花盛放、心跳律动、频谱花园。支持氛围、节日、动感、音乐筛选；每个示例附参考链接。全部不需要 Gemini key 即可体验与下载。

音乐：三段原创合成配乐（冰晶风铃、霓虹节拍、森林漫步）；可导入本地浏览器支持的 MP3/WAV 等音频，最大20MB/5分钟。选取2～30秒片段，以30Hz计算音量及低/中/高三个粗略频段能量（180Hz、2200Hz一阶分频与RMS，非精密FFT频谱）。三种调制为音量律动、三频段枝丫、低频径向。可下载截取后的单声道 WAV。

Web Audio 的播放时钟驱动网页灯光；暂停/继续/时间轴同步。试听音量不影响灯光。首次试听需要用户点击。项目存储节奏数组，不存音频或密钥；刷新后上传歌曲需重新选择，原创配乐可重新应用。歌曲波形、节奏数组与文件名不发送给 Gemini。配乐配置时循环时长与片段时长保持一致；AI 修改保留既有配乐。

UF2 保留计算好的音乐灯光帧，**不包含声音，也不让 RP2040 实时听音乐**。电脑/音箱与离线板没有启动同步信号，不能保证精确对拍，长时间会漂移；若需要现场实时音乐联动，需后续增加 USB 实时帧传输或麦克风/音频输入硬件。此次固件运行时无需变更。

验证：20例帧图案互不相同、循环首尾数据一致、预览曝光单调且零值不发光；3段原创音频与静音输入能量检查；带音乐的UF2解包与同一时刻预览逐像素相等。浏览器验证了原创音乐应用、WAV实际下载、回传WAV解码、截取起点/时长、暂停、音乐UF2生成。尚未实物验证；Gemini仍需用户密钥验证。

参考案例（借鉴思路后独立实现，非代码移植）：
- WLED: https://kno.wled.ge/features/effects/
- FastLED DemoReel100: https://fastled.io/docs/d5/d25/_demo_reel100_8ino_source.html
- FastLED Pacifica: https://fastled.io/docs/d6/d86/_pacifica_8ino-example.html
- FastLED TwinkleFox: https://fastled.io/docs/df/d61/_twinkle_fox_8ino-example.html
- WLED Audio Reactive: https://kno.wled.ge/advanced/audio-reactive/
